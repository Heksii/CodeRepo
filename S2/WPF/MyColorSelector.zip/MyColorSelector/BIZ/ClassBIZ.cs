﻿using Repository;

namespace BIZ
{
    public class ClassBIZ
    {
        private ClassBackgrundColor _colorData;

        public ClassBIZ()
        {
            colorData = new ClassBackgrundColor();
        }

        public ClassBackgrundColor colorData
        {
            get { return _colorData; }
            set
            {
                if (_colorData != value)
                {
                    _colorData = value;
                }
            }
        }
    }
}
